// document ready function - shorthand
(function ($) {
  console.log('jQuery is working!');

  var root = 'http://jsonplaceholder.typicode.com';

  $.ajax({
    url: root + '/posts/1',
    method: 'GET'
  }).then(function(data) {
    console.log(data);

    document.write('<h1>' + data.title + '</h1>');

    document.write('<p>' + data.body + '</p>');
  });

}(jQuery));
